﻿using BepInEx;
using BepInEx.Configuration;
using HarmonyLib;
using UnityEngine;
using GorillaLocomotion;

[BepInPlugin("com.gore.unitycubepet", "Unity Cube Pet", "7.0.0")]
public class UnityCubePet : BaseUnityPlugin
{
    internal static ConfigEntry<string> CubeName;

    Harmony harmony;
    public static GameObject Cube;
    public static CubeNameTag NameTag;

    void Awake()
    {
        CubeName = Config.Bind(
            "Cube Pet",
            "Name",
            "Cube",
            "Name shown above your cube pet"
        );

        harmony = new Harmony("com.gore.unitycubepet");
        harmony.PatchAll();

        Logger.LogInfo("UnityCubePet loaded (config-based)");
    }
}

[HarmonyPatch(typeof(GTPlayer), "OnEnable")]
class GTPlayer_OnEnable_Patch
{
    static void Postfix(GTPlayer __instance)
    {
        if (__instance != GTPlayer.Instance) return;
        if (UnityCubePet.Cube != null) return;

        GameObject cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
        cube.name = "UnityCubePet";
        cube.transform.localScale = Vector3.one * 0.25f;
        cube.transform.position = __instance.transform.position + Vector3.up * 0.5f;

        BoxCollider col = cube.GetComponent<BoxCollider>();
        PhysicsMaterial mat = new PhysicsMaterial
        {
            dynamicFriction = 1f,
            staticFriction = 1f,
            bounciness = 0f
        };
        col.material = mat;

        Rigidbody rb = cube.AddComponent<Rigidbody>();
        rb.mass = 1.2f;
        rb.useGravity = true;
        rb.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
        rb.interpolation = RigidbodyInterpolation.Interpolate;
        rb.solverIterations = 12;
        rb.solverVelocityIterations = 12;

        cube.layer = GTPlayer.Instance.gameObject.layer;

        Renderer r = cube.GetComponent<Renderer>();
        r.material = new Material(Shader.Find("GorillaTag/UberShader"));
        r.material.color = Color.gray;

        cube.AddComponent<CubeFollower>();

        UnityCubePet.NameTag = cube.AddComponent<CubeNameTag>();
        UnityCubePet.NameTag.SetName(UnityCubePet.CubeName.Value);

        UnityCubePet.Cube = cube;
        Object.DontDestroyOnLoad(cube);
    }
}

class CubeFollower : MonoBehaviour
{
    Rigidbody rb;
    Transform player;

    const float leashDistance = 0.6f;
    const float maxSpeed = 4.2f;
    const float baseForce = 18f;
    const float catchupForce = 55f;
    const float teleportDistance = 9f;

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
        player = GTPlayer.Instance.transform;
    }

    void FixedUpdate()
    {
        if (player == null) return;

        Vector3 target = player.position;
        Vector3 delta = target - transform.position;
        delta.y = 0f;

        float dist = delta.magnitude;

        if (dist > leashDistance)
        {
            float force = Mathf.Lerp(baseForce, catchupForce, dist / 4f);
            rb.AddForce(delta.normalized * force, ForceMode.Force);
        }

        Vector3 vel = rb.linearVelocity;
        Vector3 flatVel = new Vector3(vel.x, 0f, vel.z);

        if (flatVel.magnitude > maxSpeed)
        {
            flatVel = flatVel.normalized * maxSpeed;
            rb.linearVelocity = new Vector3(flatVel.x, vel.y, flatVel.z);
        }

        if (Vector3.Distance(transform.position, player.position) > teleportDistance)
        {
            rb.position = player.position + Vector3.up * 0.4f;
            rb.linearVelocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
        }
    }
}
public class CubeNameTag : MonoBehaviour
{
    TextMesh text;
    Transform cam;
    string lastName = "";

    void Awake()
    {
        GameObject t = new GameObject("CubeName");
        t.transform.SetParent(transform);
        t.transform.localPosition = new Vector3(0, 0.35f, 0);

        text = t.AddComponent<TextMesh>();
        text.fontSize = 48;
        text.characterSize = 0.02f;
        text.anchor = TextAnchor.MiddleCenter;
        text.color = Color.white;

        cam = Camera.main.transform;
    }

    public void SetName(string n)
    {
        text.text = n;
        lastName = n;
    }

    void Update()
    {
        if (UnityCubePet.CubeName.Value != lastName)
        {
            SetName(UnityCubePet.CubeName.Value);
        }
    }

    void LateUpdate()
    {
        if (cam == null) return;
        text.transform.rotation =
            Quaternion.LookRotation(text.transform.position - cam.position);
    }
}
